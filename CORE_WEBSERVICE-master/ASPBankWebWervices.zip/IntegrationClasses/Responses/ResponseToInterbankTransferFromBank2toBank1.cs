﻿using System;

namespace Integration.Responses
{
    [Serializable]
    public class ResponseToInterbankTransferFromBank2toBank1 : Response
    {
        public ResponseToInterbankTransferFromBank2toBank1()
        {

        }
    }
}