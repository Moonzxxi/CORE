﻿using System;

namespace ConsumirDummy
{
    [Serializable]
    public class ResponseToInterbankTransferFromBank2toBank1 : Response
    {
        public ResponseToInterbankTransferFromBank2toBank1()
        {

        }
    }
}