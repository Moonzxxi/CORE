﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace ASPBankWebWervices.Services
{
    [WebService(Namespace = "http://programming-3-section.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    public class InterbankServices : System.Web.Services.WebService
    {

    }
}
